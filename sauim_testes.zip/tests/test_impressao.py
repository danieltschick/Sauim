"""Impressão (gerando PDF, sem impressora de verdade).

Regressões: número de página aparecendo sozinho no rodapé, e a divisão das
páginas na impressão não bater com a da tela.
"""
import pytest
from PySide6.QtPrintSupport import QPrinter

from ajudas import pagina_valida

pypdf = pytest.importorskip("pypdf")


def _imprimir_em_pdf(janela, qtbot, caminho):
    janela.grab()
    qtbot.waitUntil(lambda: pagina_valida(janela.text_edit), timeout=2000)
    impressora = janela._preparar_impressora()
    impressora.setOutputFormat(QPrinter.PdfFormat)
    impressora.setOutputFileName(str(caminho))
    janela.text_edit.document().print_(impressora)
    return pypdf.PdfReader(str(caminho))


def test_pdf_nao_tem_numero_de_pagina(janela, qtbot, tmp_path):
    janela.text_edit.setPlainText("Texto de teste")
    leitor = _imprimir_em_pdf(janela, qtbot, tmp_path / "a.pdf")
    texto = leitor.pages[0].extract_text()
    assert "Texto de teste" in texto
    assert not any(c.isdigit() for c in texto), f"apareceu um número no PDF: {texto!r}"


def test_pdf_tem_as_mesmas_paginas_que_a_tela_mostra(janela, qtbot, tmp_path):
    ed = janela.text_edit
    ed.setPlainText("linha\n" * 150)
    leitor = _imprimir_em_pdf(janela, qtbot, tmp_path / "b.pdf")
    assert ed.document().pageCount() >= 2
    assert len(leitor.pages) == ed.document().pageCount()


@pytest.mark.parametrize("largura_mm, altura_mm, largura_pt, altura_pt", [
    (210.0, 297.0, 595.3, 841.9),      # A4
    (215.9, 279.4, 612.0, 792.0),      # Carta
])
def test_pdf_usa_o_papel_configurado(janela, qtbot, tmp_path,
                                     largura_mm, altura_mm, largura_pt, altura_pt):
    janela.text_edit.configurar_pagina(largura_mm, altura_mm, 25)
    leitor = _imprimir_em_pdf(janela, qtbot, tmp_path / "c.pdf")
    caixa = leitor.pages[0].mediabox
    assert float(caixa.width) == pytest.approx(largura_pt, abs=2)
    assert float(caixa.height) == pytest.approx(altura_pt, abs=2)


def test_imprimir_nao_marca_o_documento_como_modificado(janela, qtbot, tmp_path):
    janela.text_edit.setPlainText("Texto de teste")
    janela.text_edit.document().setModified(False)
    _imprimir_em_pdf(janela, qtbot, tmp_path / "d.pdf")
    assert not janela.text_edit.document().isModified()
